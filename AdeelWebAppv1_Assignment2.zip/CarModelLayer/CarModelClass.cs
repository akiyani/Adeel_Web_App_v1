﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel;

namespace CarModelLayer
{
    public class CarModelClass
    {
        [DisplayName("Car Model")]
        public string Model { get; set; }


        [DisplayName("Description")]
        public string Description { get; set; }


        [DisplayName("HP")]
        public string Horsepower { get; set; }
    }

}
